package Homework;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class IDLListTest {
	
	@Test
	public void testAdd1() {
		IDLList<Integer> tester = new IDLList<>();
		
		for (int i = 0; i < 10; i++) {
			tester.add(i);
		}
		
		tester.add(1);
		assertEquals(Integer.valueOf(1), tester.get(0));
		assertTrue(tester.add(1));

		tester.add(2);
		assertEquals(Integer.valueOf(2), tester.get(0));
		assertTrue(tester.add(1));
	}

	@Test
	public void testAdd2() {
		IDLList<Integer> tester = new IDLList<>();
		
		for (int i = 0; i < 10; i++) {
			tester.add(i);
		}
		
		tester.add(1, 2);
		assertEquals(Integer.valueOf(2), tester.get(1));
		
		tester.add(3, 8);
		assertEquals(Integer.valueOf(8), tester.get(3));
		
		try {
			tester.add(20, 0);
			fail();
		} catch (IndexOutOfBoundsException e) {
			assertEquals(1, 1);
		}
	}
	
	@Test
	public void testAppend() {
		IDLList<Integer> tester = new IDLList<>();
		
		for (int i = 0; i < 10; i++) {
			tester.add(i);
		}
		
		tester.append(5);
		assertEquals(Integer.valueOf(5), tester.get(tester.size() - 1));
		assertTrue(tester.append(5));

		tester.append(14);
		assertEquals(Integer.valueOf(14), tester.get(tester.size() - 1));
		assertTrue(tester.append(14));
	}
	
	@Test
	public void testGet() {
		IDLList<Integer> tester = new IDLList<>();

		for (int i = 0; i < 10; i++) {
			tester.add(i);
		}
		
		assertEquals(Integer.valueOf(0), tester.get(tester.size() - 1));

		assertEquals(Integer.valueOf(5), tester.get(0));
	}
	
	@Test
	public void testGetHead() {
		IDLList<Integer> tester = new IDLList<>();

		for (int i = 0; i < 10; i++) {
			tester.add(i);
		}

		assertEquals(tester.get(0), tester.getHead());

		
		IDLList<Integer> tester2 = new IDLList<>();

		for (int i = 10; i > -1; i--) {
			tester2.add(i);
		}

		assertEquals(tester2.get(0), tester2.getHead());
	}
	
	@Test
	public void testGetLast() {
		IDLList<Integer> tester = new IDLList<>();

		for (int i = 0; i < 10; i++) {
			tester.add(i);
		}

		assertEquals(tester.get(tester.size() - 1), tester.getLast());

		IDLList<Integer> tester2 = new IDLList<>();

		for (int i = 10; i > -1; i--) {
			tester2.add(i);
		}

		assertEquals(tester2.get(tester2.size() - 1), tester2.getLast());
	}
	
	@Test
	public void testSize() {
		IDLList<Integer> tester = new IDLList<>();

		for (int i = 0; i < 10; i++) {
			tester.add(i);
		}

		assertEquals(tester.size(), tester.size());

		tester.add(50);

		assertEquals(tester.size(), tester.size());
	}
	
	@Test
	public void testRemove() {
		IDLList<Integer> tester = new IDLList<>();

		// An exception should be thrown here
		try {
			tester.remove();
			fail();
		} catch (IllegalStateException e) {
			assertEquals(1, 1);
		}

		for (int i = 0; i < 10; i++) {
			tester.add(i);
		}

		assertEquals(tester.get(0), tester.remove());

		tester.remove();
		
		assertEquals(tester.get(0), tester.remove());

	}
	
	@Test
	public void testRemoveLast() {
		IDLList<Integer> tester = new IDLList<>();

		// An exception should be thrown here
		try {
			tester.removeLast();
			fail();
		} catch (IllegalStateException e) {
			assertEquals(1, 1);
		}

		for (int i = 0; i < 10; i++) {
			tester.add(i);
		}

		assertEquals(tester.get(tester.size() - 1), tester.removeLast());

		tester.removeLast();
		
		assertEquals(tester.get(tester.size() - 1), tester.removeLast());
	}
	
	@Test
	public void testRemoveAt() {
		IDLList<Integer> tester = new IDLList<>();

		for (int i = 0; i < 10; i++) {
			tester.add(i);
		}

		// An exception should be thrown here
		try {
			tester.removeAt(100);
			fail();
		} catch (IllegalStateException e) {
			assertEquals(1, 1);
		}

		assertEquals(tester.get(0), tester.removeAt(0));

		assertEquals(tester.get(tester.size() - 1), tester.removeAt(tester.size() - 1));

		assertEquals(tester.get(3), tester.removeAt(3));
	}
	
	@Test
	public void testRemove2() {
		IDLList<Integer> tester = new IDLList<>();

		for (int i = 0; i < 10; i++) {
			tester.add(i);
		}

		assertFalse(tester.remove(50));
		assertTrue(tester.remove(0));

		tester.remove(0);
		
		assertNotEquals(tester.get(tester.size() - 1), Integer.valueOf(0));

		tester.append(7);
		tester.append(7);
		
		assertEquals(tester.get(tester.size() - 1), Integer.valueOf(7));
	}
	
	@Test
	public void testToString() {
		IDLList<Integer> tester = new IDLList<>();

		for (int i = 0; i < 10; i++) {
			tester.add(i);
		}

		assertEquals("0, 1, 2, 3, 4, 5, 6, 7, 8, 9,", tester.toString());
	}
}
