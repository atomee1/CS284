package Homework;

import java.util.ArrayList;

// William Ee
// CS 284-E
// I pledge my honor that I have abided by the Stevens Honor System.

public class IDLList<E> {
	private class Node<E> {
	
		private E elem;
		private Node<E> next;
		private Node<E> prev;
		
		public Node(E elem) {
			this.elem = elem;
			next = null;
			prev = null;
		}
		
		public Node(E elem, Node<E> prev, Node<E> next) {
			this.elem = elem;
			this.next = prev;
			this.prev = next;
		}
	}
	
	private Node<E> head;
	private Node<E> tail;
	private int size;
	private ArrayList<Node<E>> ind;
	
	public IDLList() {
		this.head = null;
		this.tail = null;
		this.size = 0;
		this.ind = new ArrayList<>();
	}
	
	public boolean add(int index, E elem) {
		if (index > size || index < 0) {
			throw new IndexOutOfBoundsException();
		}
		
		if (index == 0) {
			add(elem);
		} else {
			Node<E> curr = ind.get(index);
			Node<E> newCurr = new Node<>(elem, curr.prev, curr);
			
			curr.prev.next = newCurr;
			curr.prev = newCurr;
			
			size++;
			
			ind.add(index, newCurr);
		}
		
		return true;
	}
	
	public boolean add(E elem) {
		if (head == null) {
			head = new Node<E>(elem);
			tail = head;
		} else if (head == tail) {
			head = new Node<E>(elem, null, tail);
			tail.prev = head;
		} else {
			head = new Node<E>(elem, null, head);
			head.next.prev = head;
		}
		
		ind.add(0, head);
		
		size++;
		
		return true;
	}
	
	public boolean append(E elem) {
		if (head == null) {
			head = new Node<E>(elem);
			tail = head;
			
			size++;
			
			return ind.add(head);
		}
		
		if (head == tail) {
			tail = new Node<E>(elem, head, null);
			head.next = tail;
			
			size++;
			
			return ind.add(tail);
		}
		
		tail.next = new Node<E>(elem, tail, null);
		tail = tail.next;
		
		size++;
		return ind.add(tail);
	}
	
	public E get(int index) {
		if (index > size - 1 || head == null || index < 0) {
			throw new IllegalArgumentException();
		} else {
			if (index == 0) {
				return head.elem;
			} else {
				Node<E> curr = head;
				int i = 0;
				
				while (i < index) {
					curr = curr.next;
					
					i++;
				}
				
				return curr.elem;
			}
		}
	}
	
	public E getHead() {
		if (head == null) {
			throw new IllegalArgumentException();
		}
		
		return head.elem;
	}
	
	public E getLast() {
		if (size == 0) {
			throw new IllegalArgumentException();
		}
		
		return tail.elem;
	}
	
	public int size() {
		return size;
	}
	
	public E remove() {
		if (head == null) {
			throw new IllegalArgumentException();
		}
		
		if (head == tail) {
			Node<E> temp = head;
			head = null;
			tail = null;
			
			size--;
			
			ind.clear();
			
			return temp.elem;
		}
		
		Node<E> temp = head;
		head = head.next;
		
		ind.remove(0);
		
		size--;
		
		return temp.elem;
	}
	
	public E removeLast() {
		if (head == null) {
			throw new IllegalStateException();
		}
		
		if (head == tail) {
			Node<E> temp = tail;
			head = null;
			tail = null;
			
			size = 0;
			
			ind.clear();
			
			return temp.elem;
		}
		
		Node<E> temp = tail;
		tail = tail.prev;
		tail.next = null;
		ind.remove(size - 1);
		
		size--;
		
		return temp.elem;
	}
	
	public E removeAt(int index) {
		if (index > size || index < 0) {
			throw new IllegalStateException();
		}
		
		if (index == 0) {
			return remove();
		}
		
		if (index == size - 1) {
			return removeLast();
		}
		
		Node<E> curr = ind.remove(index);
		curr.prev.next = curr.next;
		curr.next.prev = curr.prev;
		
		size--;
		
		return curr.elem;
	}
	
	public boolean remove(E elem) {
		if (elem.equals(head.elem)) {
			remove();
			
			return true;
		}
		
		if (elem.equals(tail.elem)) {
			removeLast();
			
			return true;
		}
		
		Node<E> curr = head;
		int i = 0;
		
		while (curr != null) {
			if (curr.elem.equals(elem)) {
				curr.prev.next = curr.next;
				curr.next.prev = curr.prev;
				ind.remove(i);
				
				size--;
				
				return true;
			}
			
			curr = curr.next;
			i++;
		}
		
		return false;
	}
	
	public String toString() {
		Node<E> curr = head;
		String str = "";
		
		while (curr != null) {
			str = str + curr.elem + ",";
			curr = curr.next;
		}
		
		return str;
	}
}